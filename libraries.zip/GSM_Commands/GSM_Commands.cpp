#include <FastSerial.h>
#include <GSM_Commands.h>

FastSerialPort1(Serial1);

GSM_Commands::GSM_Commands(int baud)
{
 
  //Initialize Serial communication
  Serial1.begin(baud);
}

// AT Command Sender
// AT Command, Delay before issue command
String GSM_Commands::SEND_AT_COMMAND(String input, int wait){ 

  String response = "";

  // Just making sure, you never know...
  if(wait < 0)
  {
    wait = 0;
  }

  // Send input command to modem
  Serial1.print(input + "\r"); 
  delay(wait); 

  if(Serial1.available())
  { 
    // Store response string in "response" and clear buffer
    response = Serial1.readString(); 
    Serial1.read(); 
  }

  return response; 
}   

/****************************************
 * Returns the name of the carrier
 ****************************************/

String GSM_Commands::GET_CARRIER(){

  String carrier = "";

  // Ask modem for carrier name
  String response = SEND_AT_COMMAND("AT+COPS?",100);

  // Extract carrier name from modem response
  int startIndex = response.indexOf('"');
  int endIndex = response.indexOf('"', startIndex + 1);

  carrier = response.substring(startIndex,endIndex);

  return carrier;
} 

/********************************************
 * Disables echo for the modem
 *******************************************/

int GSM_Commands::DISABLE_ECHO() {

  if(SEND_AT_COMMAND("ATE0",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************
 * Checks the connection to the GSM network
 *******************************************/

int GSM_Commands::GSM_STATUS() {

  if(SEND_AT_COMMAND("AT+CREG?",100).indexOf(",1") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************
 * Checks the connection to the GPRS network
 *******************************************/

int GSM_Commands::GPRS_STATUS() {

  if(SEND_AT_COMMAND("AT+CGREG?",100).indexOf(",1") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************************
 * Changes the SMS mode to text 
 ********************************************************/

int GSM_Commands::SMS_MODE() {

  if(SEND_AT_COMMAND("AT+CMGF=1",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************************
 * NOTIFICATIONS : ON - SMS STORAGE : SIM
 ********************************************************/

int GSM_Commands::SMS_NOTIFICATION() {
  
  // New short message is recieved and output directly to TE

  if(SEND_AT_COMMAND("AT+CNMI=1,2,0,0,0",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

/****************************************************
 * Read incoming data from the modem
 ****************************************************/

String GSM_Commands::READ() {

  if(Serial1.available()) {

    return Serial1.readString();
  }

  return "";
}

SMS GSM_Commands::NEXT() {

  String response = READ();

  if(response.indexOf("CMT") > 0)
  {
    int phone_start = 12;
    int phone_end = 22;
    int date_start = 26;
    int date_end = 45;

    int msg_start = 51;

    // response starts with "\n", remove it.
    //response = response.substring(1);

    sms.set_phone(response.substring(phone_start,phone_end));
    sms.set_date(response.substring(date_start,date_end));
    sms.set_msg(response.substring(msg_start));
    return sms;
  }

  sms.set_phone("");
  sms.set_date("");
  sms.set_msg("");
  return sms;
}

/********************************************************
 * 
 ********************************************************/

int GSM_Commands::SET_MODEM_BAUD(int baud) {
  
  // New short message is recieved and output directly to TE

  if(SEND_AT_COMMAND("AT+IPR="+baud+'\r',100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************************
 * 
 ********************************************************/

int GSM_Commands::SET_TRANSPARENT_TRANSFERRING_MODE() {
  

  if(SEND_AT_COMMAND("AT+QIMODE=1",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************************
 * 
 ********************************************************/

int GSM_Commands::SET_NORMAL_TRANSFERRING_MODE() {
  


  if(SEND_AT_COMMAND("AT+QIMODE=0",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************************
 * 
 ********************************************************/

int GSM_Commands::GPRS_CONNECT() {
  

  if(SEND_AT_COMMAND("AT+QIREGAPP = \"internet\",\"\",\"\"\r",100).indexOf("OK") > 0)
  {
    if(SEND_AT_COMMAND("AT+QIACT\r",100).indexOf("OK") > 0)
    {
      return 1;
    }
  }

  return 0;
}

/********************************************************
 * Mode UDP or TCP
 ********************************************************/

int GSM_Commands::SET_LOCAL_PORT(String mode,String port) {
  

  if(SEND_AT_COMMAND("AT+QILPORT=\""+mode+"\","+port+"\r",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

/********************************************************
 * Mode UDP or TCP
 ********************************************************/

int GSM_Commands::START_CONNECTION(String mode,String ip, String port) {
  

  if(SEND_AT_COMMAND("AT+QIOPEN=\""+mode+"\",\""+ip+"\","+port+"\r",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}

int GSM_Commands::DEACTIVATE_PDP_CONTEXT() {
  

  if(SEND_AT_COMMAND("AT+QIDEACT",100).indexOf("OK") > 0)
  {
    return 1;
  }

  return 0;
}