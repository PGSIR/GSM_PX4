#ifndef GSM_Commands_h
#define GSM_Commands_h

#include <arduino.h>

struct SMS
{
  public:
    String get_phone(){
      return phone;
    }
    String get_date(){
      return date;
    }
    String get_msg(){
      return msg;
    }
    void set_phone(String phone){
      SMS::phone = phone;
    }
    void set_date(String date){
      SMS::date = date;
    }
    void set_msg(String msg){
      SMS::msg = msg;
    }
  private:
    String phone;
    String  date;
    String  msg;
};

class GSM_Commands
{
  public:
    GSM_Commands(int baud);
    String GET_CARRIER();
    String READ();
    SMS NEXT();
    int DISABLE_ECHO();
    int GSM_STATUS();
    int GPRS_STATUS();
    int SMS_MODE();
    int SMS_NOTIFICATION();
    int SET_MODEM_BAUD(int baud);
    int SET_TRANSPARENT_TRANSFERRING_MODE();
    int SET_NORMAL_TRANSFERRING_MODE();
    int GPRS_CONNECT();
    int SET_LOCAL_PORT(String mode,String port);
    int START_CONNECTION(String mode,String ip, String port);
    int DEACTIVATE_PDP_CONTEXT();
  private:
    String SEND_AT_COMMAND(String input, int wait);
    SMS sms;
};

#endif