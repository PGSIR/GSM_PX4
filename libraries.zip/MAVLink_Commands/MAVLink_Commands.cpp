#include <FastSerial.h>
#include "M:/Active/Arduino/libraries/GCS_MAVLink/include/mavlink/v1.0/ardupilotmega/mavlink.h"
#include <MAVLink_Commands.h>

FastSerialPort2(Serial2);

MAVLink_Commands::MAVLink_Commands(int baud)
{
  //Initialize Serial communication
  Serial2.begin(baud);

  //<Message #76 COMMAND_LONG - using the mavlink_msg_command_long_pack() function
  target_system = 1;// - not really sure why this has to be at a value of 1
  target_component = 0;
  CMD_LONG_command = 0;
  CMD_LONG_confirmation = 0;
  CMD_LONG_param1 = 0;
  CMD_LONG_param2 = 0;
  CMD_LONG_param3 = 0;
  CMD_LONG_param4 = 0;
  CMD_LONG_param5 = 0;
  CMD_LONG_param6 = 0;
  CMD_LONG_param7 = 0;

  //Standard requirements for packets to have
  system_id = 255; 
  component_id = 200;
}


void MAVLink_Commands::MAV_SEND_COMMAND(unsigned int cmdid, float param1, float param2, float param3, float param4, float param5, float param6, float param7)
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  CMD_LONG_param1 = param1;
  CMD_LONG_param2 = param2;
  CMD_LONG_param3 = param3;
  CMD_LONG_param4 = param4;
  CMD_LONG_param5 = param5;
  CMD_LONG_param6 = param6;
  CMD_LONG_param7 = param7;
  CMD_LONG_command = cmdid;

  mavlink_msg_command_long_pack(system_id, component_id, &msg, target_system, target_component, CMD_LONG_command, CMD_LONG_confirmation, CMD_LONG_param1, CMD_LONG_param2, CMD_LONG_param3, CMD_LONG_param4, CMD_LONG_param5, CMD_LONG_param6, CMD_LONG_param7);
  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}
//The RAW values of the RC channels sent to the MAV to override info received from the RC radio. A value of UINT16_MAX means no change to that channel. 
//A value of 0 means control of that channel should be released back to the RC radio. The standard PPM modulation is as follows: 1000 microseconds: 0%, 2000 microseconds: 100%. 
void MAVLink_Commands::MAV_RC_OVERRIDE(float param1, float param2, float param3, float param4, float param5, float param6, float param7, float param8)
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  mavlink_msg_rc_channels_override_pack(system_id, component_id, &msg, target_system, target_component, param1, param2, param3, param4, param5, param6, param7, param8);

  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

void MAVLink_Commands::MAV_MISSION_CLEAR()
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];
  mavlink_msg_mission_clear_all_pack(system_id, component_id, &msg, target_system, target_component);

  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

void MAVLink_Commands::MAV_MISSION_LIST_REQUEST()
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  mavlink_msg_mission_request_list_pack(system_id, component_id, &msg, target_system, target_component);
  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

void MAVLink_Commands::MAV_ALTITUDE_REQUEST()
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  mavlink_msg_request_data_stream_pack(system_id, component_id, &msg, target_system, target_component, MAV_DATA_STREAM_POSITION, 1, 1);
  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

void MAVLink_Commands::MAV_MISSION_REQUEST()
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  mavlink_msg_mission_request_pack(system_id, component_id, &msg, target_system, target_component, 1);
  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

void MAVLink_Commands::MAV_SET_MODE(int mode)
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  mavlink_msg_set_mode_pack(system_id, component_id, &msg, target_system, 1, mode);
  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

void MAVLink_Commands::MAV_SET_WP(float x, float y, float z)
{
  
  uint16_t seq = 0; // Sequence is always set to 0
  uint8_t frame = MAV_FRAME_GLOBAL_RELATIVE_ALT; // Set target frame to global default
  uint16_t command = MAV_CMD_NAV_WAYPOINT; // Specific command for APM as it uses different parameters than the standard MAVLINK implementation
  uint8_t current = 2; // Guided mode waypoint
  uint8_t autocontinue = 0; // Always 0
  float param1 = 0; // Loiter time
  float param2 = 1; // Acceptable range from target - radius in meters
  float param3 = 0; // Pass through waypoint
  float param4 = 0; // Desired yaw angle

  // Initialize the required buffers
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  // Pack the message
  // NOTE : _target_systen & _target_component are defined in setup
  // found by searching mission item .h from mavlink library
  mavlink_msg_mission_item_pack(system_id, component_id, &msg, target_system, target_component, seq, frame, command, current, autocontinue, param1, param2, param3, param4, x, y, z);

  // Copy the message to the send buffer
  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

void MAVLink_Commands::MAV_SET_CURR()
{
  mavlink_message_t msg;
  uint8_t buf[MAVLINK_MAX_PACKET_LEN];

  mavlink_msg_mission_set_current_pack(system_id, component_id, &msg, target_system, target_component, 1);
  uint16_t len = mavlink_msg_to_send_buffer(buf, &msg);
  Serial2.write(buf, len);
}

